#ifndef __PULLUP_BUTTON_SENSOR_H__
#define __PULLUP_BUTTON_SENSOR_H__

#include "ButtonSensor.h"

class PullupButtonSensor : public ButtonSensor
{
public:
    virtual void SetPin(uint8_t pin)
    {
        _pin = pin;
        pinMode(pin, INPUT_PULLUP);
    }
    virtual uint8_t Value() const { return digitalRead(_pin) == HIGH ? LOW : HIGH; }
};

#endif // __PULLUP_BUTTON_SENSOR_H__
