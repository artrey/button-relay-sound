#ifndef _BUTTON_SENSOR_H_
#define _BUTTON_SENSOR_H_

enum class ButtonState
{
    HAS_BEEN_PRESSED,
    PRESSED,
    HAS_BEEN_RELEASED,
    RELEASED,
};

class ButtonSensor
{
public:
    ButtonSensor() : _pin{0}, _prev_state{0} {};
    virtual void SetPin(uint8_t pin)
    {
        _pin = pin;
        pinMode(pin, INPUT);
    }
    uint8_t Pin() const { return _pin; }
    virtual uint8_t Value() const { return digitalRead(_pin); }
    virtual uint8_t Pressed() const { return Value() == HIGH; }

    virtual ButtonState GetState()
    {
        auto pressed = Pressed();
        auto ret = pressed ? ButtonState::PRESSED : ButtonState::RELEASED;
        if (pressed != _prev_state)
        {
            ret = pressed ? ButtonState::HAS_BEEN_PRESSED : ButtonState::HAS_BEEN_RELEASED;
        }
        _prev_state = pressed;
        return ret;
    }

protected:
    uint8_t _pin;
    uint8_t _prev_state;
};

#endif // _BUTTON_SENSOR_H_
